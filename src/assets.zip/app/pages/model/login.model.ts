export class LoginModel{
    constructor(
    private empid:string="",
    private password:string="",
    ){

    }
}