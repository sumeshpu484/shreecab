export class MapmMarker{
    constructor(
    private latitude:Number=0,
    private longitude:Number=0,
    ){

    }
}