import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'driver-reg',
  templateUrl: './driver-reg.component.html',
  styleUrls: ['./driver-reg.component.scss']
})
export class DriverRegComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
