import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'add-transport-admin',
  templateUrl: './add-transport-admin.component.html',
  styleUrls: ['./add-transport-admin.component.scss']
})
export class AddTransportAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
