import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cab-reg',
  templateUrl: './cab-reg.component.html',
  styleUrls: ['./cab-reg.component.scss']
})
export class CabRegComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
