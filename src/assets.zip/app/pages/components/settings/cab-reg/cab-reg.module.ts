import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CabRegRoutingModule } from './cab-reg-routing.module';

@NgModule({
  imports: [
    CommonModule,
    CabRegRoutingModule
  ],
  declarations: []
})
export class CabRegModule { }
