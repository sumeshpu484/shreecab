export class Driver{
    constructor(
    private Id:string="",
    private name:string="",
    Idproof:string="",
    private licence:string=""){

    }
}