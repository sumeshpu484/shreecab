import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'add-route',
  templateUrl: './add-route.component.html',
  styleUrls: ['./add-route.component.scss']
})
export class AddRouteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
