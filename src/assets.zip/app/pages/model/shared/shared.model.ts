
export interface RootObject {
    status: string;
    responsepayload: Responsepayload;
}
export interface Responsepayload {
    result: any;
}